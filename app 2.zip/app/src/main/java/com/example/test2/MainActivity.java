package com.example.test2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    EditText et1user,et2pass;
    Button log;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1user = findViewById(R.id.etuser);
        et2pass = findViewById(R.id.etpass);
        log = findViewById(R.id.btnlogin);

        log.setOnClickListener(this);

    }



    public void onClick(View view) {
        if (et1user.getText().toString().equals("user1") || et2pass.getText().toString().equals("password1")) {
            Intent act = new Intent(getApplicationContext(), Main2Activity.class);

            //starting an intent
            startActivity(act);
            finish();

            //correcct password
        } else {
            Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
            //wrong password
        }


    }
}

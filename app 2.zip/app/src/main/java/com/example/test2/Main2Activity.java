package com.example.test2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity  implements AdapterView.OnItemSelectedListener, View.OnClickListener, CompoundButton.OnCheckedChangeListener
    {


        Spinner spin;
        TextView etcapital;
        ImageView iVimg;
        ListView simpleList;
        Button btnrent;
        static  int i;
        String[] capital = {"Ottawa", "Washington", "London"};
        int[] imageList={R.drawable.canadian,R.drawable.usa,R.drawable.england};
        //String poi[] = {"Ottawa Locks", "Royal Canadian Mint"};




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        spin = findViewById(R.id.spinner);
        iVimg=findViewById(R.id.img);
        etcapital=findViewById(R.id.capital);
        iVimg.setBackgroundResource(R.drawable.canadian);


        List<String> countries = new ArrayList<>();
        countries.add("CANADA");
        countries.add("USA");
        countries.add("ENGLAND");


        ArrayAdapter<String> proAdapter= new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,countries);
        proAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);


        spin.setAdapter(proAdapter);
        spin.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
            //  .setOnClickListener(this);
//        simpleList = (ListView)findViewById(R.id.simpleListView);
//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.activity_main2, poi);
//        simpleList.setAdapter(arrayAdapter);



    }

        @Override
        public void onClick(View view) {


        }

        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


           // i = position;
            String cp = new String(capital[i]);
            etcapital.setText(cp);
            int img = imageList[i];
            iVimg.setBackgroundResource(img);


        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {


        }

        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {



        }
    }
